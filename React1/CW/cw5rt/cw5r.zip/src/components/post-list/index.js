import PostList from "./post-list";
export default PostList;