import Exr2 from "./exercise2";
export default Exr2;