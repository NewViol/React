import DopRandom from './exercise1'
export default DopRandom;